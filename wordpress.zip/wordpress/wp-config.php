<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'wordpress' );

/** MySQL database password */
define( 'DB_PASSWORD', 'wordpress' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Q&QuB>oil#hnIZ@3El`fQYum1BL<01GtuEL=_6.:?l7TQbaFBsgz||Vi4Kq1~@0b' );
define( 'SECURE_AUTH_KEY',  '#hlx}yh(ZWy]<GV>B00,?4q7P_O0W~43B?PXi2[mdIQ8-0]~g5MJ,?@^XBk`GoN<' );
define( 'LOGGED_IN_KEY',    'Q1lRgH7;9Jp/Q<oNNxXAc>!<(Ud8~6n<9dGoNS=lI0/@?L;H_ ]mLTOwL+[BF+`]' );
define( 'NONCE_KEY',        'gsqJfI=v0s<(@MU)#cnM=;Be8xiAM#/pR/s)<4rQdb~`.4P]{T&[WxPrC*mySNpB' );
define( 'AUTH_SALT',        'j5af45LPgLp~L]H!kd2}v_UCkNd4*.P93S|HO*HO4+?__kv)v&x58rYwsCoG;m0W' );
define( 'SECURE_AUTH_SALT', ' K=UBx0B0ViYeekmDp*pmY,0z*mW=//`-^_Hh<b~=SoM`NSrajh7NFUU]#q/4nWv' );
define( 'LOGGED_IN_SALT',   '!l3y-kLte/V.kt`Q3W(AcQ*_gf?Wuw^O-#tIEw)i}B{*<<D]*o]raamg/[ WTYZN' );
define( 'NONCE_SALT',       'JlvvIaGOksy_=<_@gje-PtSlaWB:AE~b=?em&}+k0WTU,-^!MuUy0k4&,RL9H-VT' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
